
import crypto from "node:crypto";
const COOKIE="srineet_admin_session";
const enc=new TextEncoder();
function b64u(buf){return Buffer.from(buf).toString("base64url")}
function fromB64(s){return Buffer.from(s,"base64url")}
function secret(){const s=process.env.SESSION_SECRET;if(!s)throw new Error("SESSION_SECRET is not configured");return s}
export async function sign(value){return b64u(crypto.createHmac("sha256",secret()).update(value).digest())}
export async function makeSession(){const exp=Date.now()+8*60*60*1000;const value=`admin.${exp}`;return `${value}.${await sign(value)}`}
export async function verifySession(request){const cookie=request.headers.get("cookie")||"";const m=cookie.match(new RegExp(`${COOKIE}=([^;]+)`));if(!m)return false;const raw=m[1],parts=raw.split(".");if(parts.length!==3)return false;const value=parts.slice(0,2).join("."),sig=parts[2];if(!value.startsWith("admin."))return false;const exp=Number(value.slice(6));if(!exp||Date.now()>exp)return false;const expected=await sign(value);return crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))}
export function setCookie(v){return `${COOKIE}=${v}; Path=/; HttpOnly; SameSite=Strict; Secure; Max-Age=28800`}
export function clearCookie(){return `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Secure; Max-Age=0`}
export function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8",...headers}})}
export function requireEnv(){if(!process.env.ADMIN_PASSWORD||!process.env.SESSION_SECRET)throw new Error("Admin environment variables are not configured")}

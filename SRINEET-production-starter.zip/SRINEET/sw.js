const CACHE = "srineet-shell-v1";
const SHELL = [
  "/", "/index.html",
  "/assets/css/app.css", "/assets/js/app.js",
  "/assets/icons/icon.svg",
  "/data/institutes.json", "/data/batches.json", "/data/tests.json"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    fetch(e.request).then(r => {
      const copy = r.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return r;
    }).catch(() => caches.match(e.request))
  );
});


async function api(path,options={}){const r=await fetch(path,options);const text=await r.text();let data={};try{data=JSON.parse(text)}catch{}if(!r.ok)throw new Error(data.error||"Request failed");return data}
async function requireAdmin(){const s=await api("/api/admin/session");if(!s.authenticated)location.href="/admin/login.html"}
function toast(msg){const el=document.querySelector("#toast");if(el){el.textContent=msg;el.hidden=false;setTimeout(()=>el.hidden=true,2200)}}

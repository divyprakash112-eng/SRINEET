# SRINEET — Complete NEET Preparation

Production-oriented vanilla HTML/CSS/JS + Netlify Functions + Netlify Blobs architecture.

## Stack
- Frontend: HTML, CSS, Vanilla JavaScript, JSON, SVG
- Hosting: Netlify
- Serverless: Netlify Functions
- Persistent admin content: Netlify Blobs
- Student progress: localStorage
- PWA: service worker

## Local setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npx netlify dev`.
4. Set local environment variables in `.env`:
   - `ADMIN_PASSWORD`
   - `SESSION_SECRET` (long random secret)
5. Open the URL shown by Netlify CLI.

## Deployment
Connect this repository to Netlify. Build command can be empty; publish directory is `.`.
Set the same environment variables in Netlify Site configuration.

## CBT
Upload CBT HTML through `/admin/`. Published files are served at:
`/tests/{institute-slug}/{batch-slug}/{test-slug}.html`

A CBT uploaded by the admin is stored as-is in Netlify Blobs. SRINEET does not rewrite questions or answers.

## Important
The included demo content is intentionally minimal and clearly marked as starter content. Replace/add your real content through JSON or the admin panel.

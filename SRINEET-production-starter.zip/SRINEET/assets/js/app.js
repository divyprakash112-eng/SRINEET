
const SR = window.SRINEET = {
  telegram: "https://t.me/srineetofficial",
  popupKey: "srineet_telegram_seen_v1",
  getSeen(){try{return JSON.parse(localStorage.getItem(this.popupKey)||"{}")}catch{return{}}},
  markSeen(key){const x=this.getSeen();x[key]=true;localStorage.setItem(this.popupKey,JSON.stringify(x))},
  shouldPopup(key){return !this.getSeen()[key]},
  openTelegramGate(key,destination){
    if(!this.shouldPopup(key)){ if(destination) location.href=destination; return true; }
    document.querySelector("#telegramBackdrop")?.classList.add("open");
    document.querySelector("#telegramBackdrop")?.setAttribute("aria-hidden","false");
    document.querySelector("#telegramContinue")?.setAttribute("data-destination",destination||"");
    document.querySelector("#telegramContinue")?.setAttribute("data-key",key);
    document.querySelector("#telegramJoin")?.setAttribute("href",this.telegram);
    return false;
  },
  continueTelegram(){
    const b=document.querySelector("#telegramBackdrop"); if(!b)return;
    const key=document.querySelector("#telegramContinue")?.dataset.key;
    const dest=document.querySelector("#telegramContinue")?.dataset.destination;
    if(key)this.markSeen(key);
    b.classList.remove("open"); b.setAttribute("aria-hidden","true");
    if(dest) location.href=dest;
  },
  closeTelegram(){document.querySelector("#telegramBackdrop")?.classList.remove("open")},
  progress:{
    get(){try{return JSON.parse(localStorage.getItem("srineet_progress_v1")||"{}")}catch{return{}}},
    save(x){localStorage.setItem("srineet_progress_v1",JSON.stringify(x))},
    activity(type,id,meta={}){
      const p=this.get(); p.last={type,id,...meta}; p.activityDates=p.activityDates||{};
      const d=new Date().toISOString().slice(0,10); p.activityDates[d]=true;
      p.studySeconds=(p.studySeconds||0)+(meta.seconds||0); this.save(p);
    },
    bookmark(item){const p=this.get();p.bookmarks=p.bookmarks||[];const i=p.bookmarks.findIndex(x=>x.id===item.id);if(i>=0)p.bookmarks.splice(i,1);else p.bookmarks.push(item);this.save(p);return i<0},
    mistake(item){const p=this.get();p.mistakes=p.mistakes||[];if(!p.mistakes.some(x=>x.id===item.id))p.mistakes.push(item);this.save(p)},
    removeMistake(id){const p=this.get();p.mistakes=(p.mistakes||[]).filter(x=>x.id!==id);this.save(p)}
  }
};

document.addEventListener("DOMContentLoaded",()=>{
  const drawer=document.querySelector("#drawer"),back=document.querySelector("#drawerBackdrop");
  const open=()=>{drawer?.classList.add("open");back?.classList.add("open")};
  const close=()=>{drawer?.classList.remove("open");back?.classList.remove("open")};
  document.querySelector("#menuBtn")?.addEventListener("click",open);
  document.querySelector("#drawerClose")?.addEventListener("click",close);
  back?.addEventListener("click",close);
  document.querySelector("#telegramClose")?.addEventListener("click",()=>SR.closeTelegram());
  document.querySelector("#telegramContinue")?.addEventListener("click",()=>SR.continueTelegram());
  document.querySelector("#telegramJoin")?.addEventListener("click",()=>{const k=document.querySelector("#telegramContinue")?.dataset.key;if(k)SR.markSeen(k)});
  document.querySelectorAll("[data-gate]").forEach(a=>a.addEventListener("click",e=>{
    const dest=a.getAttribute("href"),key=a.dataset.gate;if(SR.shouldPopup(key)){e.preventDefault();SR.openTelegramGate(key,dest)}
  }));
  if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
});

window.renderHeader=()=>`
<header class="site-header"><div class="container nav">
<button class="icon-btn" id="menuBtn" aria-label="Open menu"><img src="/assets/icons/menu.svg"></button>
<a class="brand" href="/"><img class="brand-mark" src="/assets/icons/icon.svg"><span><span class="brand-text">SRINEET</span><span class="brand-sub">COMPLETE NEET PREPARATION</span></span></a>
<a class="icon-btn" href="/search.html" aria-label="Search">⌕</a>
</div></header>
<div class="drawer-backdrop" id="drawerBackdrop"></div>
<aside class="drawer" id="drawer"><div class="row"><div><div class="section-kicker">SRINEET</div><h2>Study Menu</h2></div><button class="icon-btn" id="drawerClose">×</button></div>
<a class="drawer-link" href="/"><span class="drawer-icon">⌂</span>Home</a>
<a class="drawer-link" data-gate="test-series" href="/test-series/"><span class="drawer-icon">▣</span>Test Series</a>
<a class="drawer-link" data-gate="pyq" href="/pyq/"><span class="drawer-icon">◇</span>PYQ Chapterwise</a>
<a class="drawer-link" data-gate="notes" href="/notes/"><span class="drawer-icon">▤</span>Smart Notes</a>
<a class="drawer-link" data-gate="practice" href="/practice/"><span class="drawer-icon">✓</span>Chapterwise Practice</a>
<div class="drawer-bottom">Focused preparation.<br><b style="color:#1687ff;letter-spacing:3px">SRINEET</b></div></aside>`;

window.renderTelegram=()=>`<div class="telegram-backdrop" id="telegramBackdrop" aria-hidden="true"><div class="telegram-modal">
<button class="modal-close" id="telegramClose" aria-label="Close">×</button><div class="telegram-mark">➤</div>
<div class="section-kicker">SRINEET COMMUNITY</div><h3>Stay connected with SRINEET.</h3><p>Join the official Telegram channel for important updates, new resources and preparation alerts.</p>
<div class="modal-actions"><a class="btn btn-primary" id="telegramJoin" target="_blank" rel="noopener" href="https://t.me/srineetofficial">Join Telegram</a><button class="btn btn-soft" id="telegramContinue">Continue to SRINEET</button></div>
</div></div>`;

window.renderFooter=()=>`<footer class="footer"><div class="container"><div class="row"><a class="brand" href="/"><img class="brand-mark" src="/assets/icons/icon.svg"><span><span class="brand-text">SRINEET</span><span class="brand-sub">Complete NEET Preparation</span></span></a><b style="font-size:12px;color:#7ee2ff">Prepare smart. Practice consistently.</b></div><p style="max-width:780px;margin:28px 0 0;font-size:12px">SRINEET is designed to bring essential NEET preparation resources together in a simple, focused and student-friendly experience.</p><div class="footer-bottom"><span>© 2026 SRINEET</span><span>Made for NEET Aspirants</span></div></div></footer>`;

async function loadJSON(path){const r=await fetch(path);if(!r.ok)throw new Error("Failed to load "+path);return r.json()}
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
